package com.cg.mobile.client;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.exceptions.InvalidCustomerNameException;
import com.cg.mobile.exceptions.InvalidMailIdException;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidPhoneNumberException;
import com.cg.mobile.exceptions.InvalidQuantityException;
import com.cg.mobile.exceptions.MobileDetailsNotFound;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.services.MobileService;
import com.cg.mobile.services.MobileServiceImpl;
import com.cg.mobile.util.ConnectionProvider;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws SQLException, PurchaseServicesDownException, InvalidQuantityException, MobileDetailsNotFound, InvalidMailIdException, InvalidCustomerNameException, InvalidPhoneNumberException, InvalidMobileIdException {
		MobileService mobileService=new MobileServiceImpl();
		Scanner  sc=new Scanner(System.in);
		String s="yes";
		Connection con=ConnectionProvider.getDBConnection();
		if(con!=null)
			System.out.println("coooon");
		while(s.equalsIgnoreCase("yes")){
			System.out.println("1.Enter Customer's purchase Details");
			System.out.println("2.Find All Mobile Details");
			System.out.println("3.Find mobile details between ranges");
			System.out.println("4.Delete mobile details");
			System.out.println("6.exit");
			System.out.println("Enter your Choice");
			int choice=sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter the name of the customer");
				String customerName=sc.next();
				System.out.println("Enter the mailId of customer");
				String mailId=sc.next();
				System.out.println("Enter customer phone number");
				String phoneNo=sc.next();
				System.out.println("Enter MobileId of mobile purchased");
				int mobileId=sc.nextInt(); 
				int purchaseId=mobileService.addPurchaseDetails(customerName, mailId, phoneNo, mobileId);
				System.out.println(purchaseId);
				break;
			case 2:
				ArrayList<Mobile> list=mobileService.findAllMobile();
				for (Mobile mobile : list) {
					System.out.println(mobile);
				}
				break;
			case 3:
				System.out.println("Enter beginning price");
				int begPrice=sc.nextInt();
				System.out.println("Enter end price");
				int endPrice=sc.nextInt();
				ArrayList<Mobile> list1=mobileService.findBetweenRange(begPrice, endPrice);
				for (Mobile mobile : list1) {
					System.out.println(mobile);
				}
				break;
			case 4:
				System.out.println("Enter mobileId to be deleted");
				int mobileId1=sc.nextInt();
				mobileService.deleteOne(mobileId1);
				ArrayList<Mobile> list11=mobileService.findAllMobile();
				for (Mobile mobile : list11) {
					System.out.println(mobile);
				}
				break;
			default:
				System.out.println("Invalid data Entered");
				break;
				
			}
			System.out.println("do you want to continue(yes/no)");
			s=sc.next();
		}
	}

}