package com.cg.mobile.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidQuantityException;

public interface MobileDAO {
	int save(PurchaseDetails purchaseDetails) throws SQLException, InvalidQuantityException;
	ArrayList<Mobile> findAllMobile() throws SQLException;
	boolean deleteOne(int mobileId) throws InvalidMobileIdException;
ArrayList<Mobile> findBetweenRange(int startingPrice,int endingPrice) throws SQLException;
	}
