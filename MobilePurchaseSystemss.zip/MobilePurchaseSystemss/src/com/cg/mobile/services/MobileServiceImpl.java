package com.cg.mobile.services;

import java.security.InvalidParameterException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.dao.MobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.exceptions.InvalidCustomerNameException;
import com.cg.mobile.exceptions.InvalidMailIdException;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidPhoneNumberException;
import com.cg.mobile.exceptions.InvalidQuantityException;
import com.cg.mobile.exceptions.MobileDetailsNotFound;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
public class MobileServiceImpl implements MobileService{
	
	MobileDAO mobileDao=new MobileDAOImpl();
	private static final Logger logger=Logger.getLogger(MobileServiceImpl.class);

	@Override
	public int addPurchaseDetails(String customerName,String mailId,String phoneNo,int mobileId)
			throws SQLException, PurchaseServicesDownException, InvalidQuantityException, InvalidMailIdException, InvalidCustomerNameException, InvalidPhoneNumberException, InvalidMobileIdException {
		int purchaseId;
		if(!Pattern.matches("[A-Z][a-zA-Z]{0,19}", customerName))
		throw new InvalidCustomerNameException("Invalid customer name");
		if(!Pattern.matches("[a-zA-Z][a-zA-Z0-9-_.]{1,}[@][a-zA-Z]{5,}[.][a-zA-Z]{3,}",mailId))
		throw new InvalidMailIdException("Invalid Mail Id");
		if(!Pattern.matches("[1-9][0-9]{9}", phoneNo))
			throw new InvalidPhoneNumberException("Invalid phone number");
		if(!(mobileId>=1000&&mobileId<=9999))
			throw new InvalidMobileIdException("Invalid MobileId");
		try{
			PurchaseDetails purchaseDetails=new PurchaseDetails(customerName, mailId, phoneNo,new Mobile(mobileId));
		purchaseId=mobileDao.save(purchaseDetails);
		return purchaseId;
		}catch(SQLException e){
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw new PurchaseServicesDownException("purchase services is down",e);
		}
	}

	@Override
	public ArrayList<Mobile> findAllMobile() throws SQLException, PurchaseServicesDownException {
		try{
		return mobileDao.findAllMobile();
		}catch(SQLException e){
			throw new PurchaseServicesDownException("Services down",e);
		}
	}

	@Override
	public boolean deleteOne(int mobileId) throws InvalidMobileIdException {
			try {
				return mobileDao.deleteOne(mobileId);
			} catch (InvalidMobileIdException e) {
				e.printStackTrace();
			}
			return false;
		
	}

	@Override
	public ArrayList<Mobile> findBetweenRange(int startingPrice, int endingPrice) throws PurchaseServicesDownException {
		try{
			return mobileDao.findBetweenRange(startingPrice, endingPrice);
		}catch(Exception e){
			throw new PurchaseServicesDownException();
		}
	}


}

