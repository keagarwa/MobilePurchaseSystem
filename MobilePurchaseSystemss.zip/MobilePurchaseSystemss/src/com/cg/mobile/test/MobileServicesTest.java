package com.cg.mobile.test;

public class MobileServicesTest {

}
